package org.Piotrowski;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class Manager {
    private ObjectMapper objectMapper;

    private List<WorldBank> wbList;
    private List<WorldBank> listOfCountriesInDB;
    private WorldBank[] worldBanksArray;

    private File file;

    public Manager() {
        objectMapper = null;

        wbList = null;
        listOfCountriesInDB = null;
        worldBanksArray = null;

        file = null;

        process();
    }

    public void process(){
        initVariables();
        initList();
        initArray();
        initCountryList();

        countProjectsForCountry();
        countProjectCostForCountries();

        revertSortingForList();
    }


    // -------INIT------- //

    private void initVariables() {

        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        wbList = new ArrayList<>();
        listOfCountriesInDB = new ArrayList<>();

        file = new File(getPath());

    }

    private void initList() {

        try {
            JsonParser jsonParser = objectMapper.getFactory().createParser(file);

            while (jsonParser.nextToken() != null) {

                WorldBank wb = objectMapper.readValue(jsonParser, WorldBank.class);

                wbList.add(wb);
            }
        } catch (IOException e) {
            System.out.println("Failed to initList");
        }

    }

    private void initArray(){
        worldBanksArray = new WorldBank[wbList.size()];

        for (int i = 0; i < wbList.size(); i++) {
            WorldBank wb = wbList.get(i);
            worldBanksArray[i]=wb;
        }

    }

    private void initCountryList() {

        sortListByCountry();

            for (int i = 0; i < wbList.size(); i++) {
                if (i != 0) {
                    if (!wbList.get(i).getCountryname().equals(wbList.get(i - 1).getCountryname())) {
                        listOfCountriesInDB.add(new WorldBank(wbList.get(i).getCountryname(), wbList.get(i).getCountryshortname()));

                    }
                } else {
                    listOfCountriesInDB.add(new WorldBank(wbList.get(i).getCountryname(), wbList.get(i).getCountryshortname()));
                }
            }
    }


    // --------COUNT------- //

    private void countProjectsForCountry(){
        for (WorldBank wb : wbList) {

            for (WorldBank wb2 : listOfCountriesInDB) {
                if (wb2.getCountryshortname().equals(wb.getCountryshortname())){

                    wb2.setNumOfProjects(wb2.getNumOfProjects()+1);
                }
            }

        }

    }

    private void countProjectCostForCountries(){

        for (WorldBank wb : wbList) {

            for (WorldBank wb2 : listOfCountriesInDB) {
                if (wb2.getCountryshortname().equals(wb.getCountryshortname())){

                    wb2.setLendProjectCostForCountry(wb2.getLendProjectCostForCountry()+wb.getLendprojectcost());
                }
            }

        }
    }

    // -------SORT------- //

    private void sortListByCountry(){
        wbList.sort(((o1, o2) -> o1.getCountryname().compareTo(o2.getCountryname())));
    }

    public void sortListByProjectsNum(){
        listOfCountriesInDB.sort((Comparator.comparingInt(WorldBank::getNumOfProjects)));
        Collections.reverse(listOfCountriesInDB);
    }

    public void sortListByProjectCostForCountry() {
        listOfCountriesInDB.sort((Comparator.comparingLong(WorldBank::getLendProjectCostForCountry)));
        Collections.reverse(listOfCountriesInDB);
    }

    private void revertSortingForList() {
        wbList.clear();

        for (WorldBank wb : worldBanksArray) {
            wbList.add(wb);
        }
    }

    // ----------DISPLAY-------- //

    public void displayList() {
        int index=1;

        System.out.println("list:");
        for (WorldBank wb : wbList) {
            System.out.println(index+". "+wb.getCountryname()+" "+wb.getLendprojectcost()+" "+wb.get_id().get$oid());
            index++;

        }
    }

    public void displayCountriesWithNumberOfProjects(int numberOfRecordsToShow) {

        for (int i = 0; i < numberOfRecordsToShow; i++) {
            System.out.println(i+1+". Country: "+listOfCountriesInDB.get(i).getCountryshortname()+
                    ", num of projects: "+listOfCountriesInDB.get(i).getNumOfProjects());
        }
    }

    public void displayCountryWithProjectCost(int numberOfRecordsToShow){

        for (int i = 0; i < numberOfRecordsToShow; i++) {
            System.out.println(i+1+". Country: "+listOfCountriesInDB.get(i).getCountryshortname()+
                    ", cost of projects: "+listOfCountriesInDB.get(i).getLendProjectCostForCountry());
        }
    }

    // ----------GET-------- //

    public List<WorldBank> getListOfCountriesInDB() {
        return listOfCountriesInDB;
    }

    private String getPath() {
        System.out.println("Input absolute path to world_bank.json file:");
        Scanner scanner = new Scanner(System.in);

        return scanner.nextLine();
    }

}
