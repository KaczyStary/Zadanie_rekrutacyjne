package org.Piotrowski;

import java.util.Scanner;
import java.util.stream.IntStream;

public class Interface {

    Scanner scanner;
    Manager manager;
    int choice;
    int numberOfRecordsToShow;

    public Interface() {
        Start();
    }

    private void Start(){

        initVariablesInterface();
        introduction();
        run();

    }


    private void introduction(){
        System.out.println("Hello :)");
    }

    private void instruction(){
        System.out.println();
        System.out.println("Press: 1 -> 1st task - wyswietl 10 regionow, w ktorych zostalo zrealizowane najwiecej projektow");
        System.out.println("Press: 2 -> 2nd task - wyswietl 10 regionow, w ktore zainewstowano najwiecej pieniedzy");
        System.out.println("Press: 3 -> 1st task, with custom number of records");
        System.out.println("Press: 4 -> 2nd task, with custom number of records");
        System.out.println("Press: 5 -> original list");
        System.out.println("Press: 6 -> Quit");
        System.out.println();
    }

    private void initVariablesInterface(){
        scanner = new Scanner(System.in);
        manager =new Manager();

        choice=0;
        numberOfRecordsToShow =0;
    }
    private void run(){

        while (true) {

            instruction();

            switch (getChoice()) {
                case 0:
                    System.out.println("Just in case, if smth would bring u here");
                    break;
                case 1:
                    manager.sortListByProjectsNum();
                    manager.displayCountriesWithNumberOfProjects(10);
                    break;
                case 2:
                    manager.sortListByProjectCostForCountry();
                    manager.displayCountryWithProjectCost(10);
                    break;
                case 3:
                    numberOfRecordsToShow();
                    manager.sortListByProjectsNum();
                    manager.displayCountriesWithNumberOfProjects(numberOfRecordsToShow);
                    break;
                case 4:
                    numberOfRecordsToShow();
                    manager.sortListByProjectCostForCountry();
                    manager.displayCountryWithProjectCost(numberOfRecordsToShow);
                    break;
                case 5:
                    manager.displayList();
                    break;
                case 6:
                    quit();
                    break;
            }
        }
    }

    private int getChoice(){

        boolean correctInput=false;
        int minInput=1;
        int maxInput=6;


        while (!correctInput){

            System.out.print("Input: ");
            choice=scanner.nextInt();

            if(IntStream.rangeClosed(minInput, maxInput).boxed().toList().contains(choice)){
                correctInput=true;
            }else{
                System.out.println("Wrong input, here is instruction: ");
                instruction();
            }

        }

        return choice;
    }

    private int numberOfRecordsToShow() {
        System.out.println("Number of records to show: ");

        boolean correctNumber=false;
        while (!correctNumber){

            numberOfRecordsToShow =scanner.nextInt();
            if (numberOfRecordsToShow >=0&& numberOfRecordsToShow <=manager.getListOfCountriesInDB().size()){
                correctNumber = true;
            }else {
                System.out.println("incorect input,min: 0, max: "+manager.getListOfCountriesInDB().size());
            }

        }

        return numberOfRecordsToShow;
    }

    private void quit(){
        System.exit(0);
    }
}
