package org.Piotrowski;

public class Main {
    public static void main(String[] args)  {

        Interface anInterface = new Interface();

    }

}

