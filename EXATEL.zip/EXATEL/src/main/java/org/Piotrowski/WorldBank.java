package org.Piotrowski;

public class WorldBank {
    // ----------JSON_VAR------- //
    private IDkey _id;
    private String countryname;
    private String countryshortname;
    private long lendprojectcost;

    // ----------MY_VAR--------- //
    private int numOfProjects;
    private long lendProjectCostForCountry;


    public WorldBank() {
    }
    public WorldBank(String countryname, String countryshortname) {
        this.countryname = countryname;
        this.countryshortname=countryshortname;
    }
    public long getLendProjectCostForCountry() {
        return lendProjectCostForCountry;
    }
    public String getCountryshortname() {
        return countryshortname;
    }
    public int getNumOfProjects() {
        return numOfProjects;
    }
    public String getCountryname() {
        return countryname;
    }
    public long getLendprojectcost() {
        return lendprojectcost;
    }
    public IDkey get_id() {
        return _id;
    }
    public void set_id(IDkey _id) {
        this._id = _id;
    }
    public void setNumOfProjects(int numOfProjects) {
        this.numOfProjects = numOfProjects;
    }
    public void setLendProjectCostForCountry(long lendProjectCostForCountry) {
        this.lendProjectCostForCountry = lendProjectCostForCountry;
    }
}
